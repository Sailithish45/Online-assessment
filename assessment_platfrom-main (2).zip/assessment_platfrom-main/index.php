<?php

header("Location: login_student");

?>